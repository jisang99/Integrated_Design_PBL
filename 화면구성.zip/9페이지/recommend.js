let preButton = document.querySelector(".preButton");

preButton.addEventListener("click", function () {
  window.location.href = "../8페이지/filter8.html";
});



// 밑에부터 수정해

